const Sequelize = require('sequelize');
const sequelize = require('../Utill/connection');


const studentDataModel = sequelize.define('studentData', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    studentname: {
        type : Sequelize.STRING,
        allowNull : false,
        required: true
    },
    fathersname: {
       type : Sequelize.STRING,
        allowNull : false,
        required: true
    },
    mothersname: {
        type : Sequelize.STRING,
         allowNull : true,
         required: false
     },
    class: {
        type : Sequelize.INTEGER,
        allowNull : false,
        required: true
    },
    address: {
        type : Sequelize.STRING,
        allowNull : true,
        required: true
    },
    mobilenumber : {
        type: Sequelize.INTEGER,
        allowNull  : false,
    },
    schoolname: {
        type : Sequelize.STRING,
        allowNull : false,
    },
    imgUrl: {
        type : Sequelize.STRING,
        allowNull : false,
        required : true
    },
   
},{
    timeStamp: true
})

module.exports=studentDataModel;