const express = require('express');
const user = require('../Controllers/userController')

const userRouter = express.Router();

userRouter.post('/', user.createUser);
userRouter.post('/finduser', user.findUserByID);
module.exports =  userRouter;