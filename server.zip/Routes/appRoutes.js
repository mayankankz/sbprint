const express = require('express');
const appController = require('../Controllers/appController')

const appRouter = express.Router();
const Multer = require('multer');


// Multer middleware for handling file uploads
const multer = Multer({
    storage: Multer.memoryStorage(),
    limits: {
        fileSize: 5 * 1024 * 1024, // 5MB file size limit
    },
});



appRouter.post('/upload', multer.single('image'),appController.uploadImageAndSaveData);

module.exports =  appRouter;