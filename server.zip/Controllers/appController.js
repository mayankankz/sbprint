
const { Storage } = require('@google-cloud/storage');


exports.uploadImageAndSaveData = async (req, res, next) => {
    const storage = new Storage({
        projectId: 'silken-mile-383309',
        keyFilename: 'D:/Mayank/ReactProjects/printSB/Server/silken-mile-383309-49640fd5a454.json',
    });
    const bucketName = 'sbonlineservicestest';
    const { schoolName, className } = req.body;
    const file = req.file;

    // Check if the file buffer exists
  if (!file || !Buffer.isBuffer(file.buffer)) {
    return res.status(400).send({ message: 'File buffer not found' });
  }

  const schoolFolderName = `${schoolName}/`;
  const classFolderName = `${schoolFolderName}${className}/`;
  const fileName = 'example.jpg'; // You can change this to the desired file name

  try {
    // Check if the school folder exists in the bucket
    const [schoolFolderExists] = await storage.bucket(bucketName).file(schoolFolderName).exists();
    if (!schoolFolderExists) {
      // If school folder does not exist, create it
      await storage.bucket(bucketName).file(schoolFolderName).createWriteStream().end();
      console.log(`School folder created successfully: ${schoolFolderName}`);
    }

    // Check if the class folder exists inside the school folder
    const [classFolderExists] = await storage.bucket(bucketName).file(classFolderName).exists();
    if (!classFolderExists) {
      // If class folder does not exist, create it
      await storage.bucket(bucketName).file(classFolderName).createWriteStream().end();
      console.log(`Class folder created successfully: ${classFolderName}`);
    }

    // Use the storage.bucket(bucketName).file() method to get a reference to the file in GCS
    const fileRef = storage.bucket(bucketName).file(`${classFolderName}${fileName}`);

    // Use the fileRef.createWriteStream() method to create a writable stream for uploading the file buffer
    const fileStream = fileRef.createWriteStream({
      metadata: {
        contentType: 'image/jpeg' // Replace with the actual content type of the file
      }
    });

    fileStream.on('error', (err) => {
      console.error(`Failed to upload file: ${err}`);
      return res.status(500).send({ message: 'Internal server error' });
    });

    fileStream.on('finish', () => {
      console.log(`File uploaded successfully to: ${classFolderName}${fileName}`);
      // Send a success response to the client
      res.status(200).send({ message: 'File uploaded successfully' });
    });

    fileStream.end(file.buffer); // Write the file buffer to the file stream

  } catch (err) {
    console.error(`Failed to upload file: ${err}`);
    return res.status(500).send({ message: 'Internal server error' });
  }
}