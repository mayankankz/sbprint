const { async } = require('q');
const User = require('../Models/userModel');
const db = require('../Utill/database');
let bcrypt = require('bcryptjs');
const { hashPassword } = require('../Utill/hashVerifyPassward');
const school = require('../Models/schoolModel');
exports.createUser = async (req, res) => {
    const { username, password, Schoolname, schoolcode } = req.body;
    const hashedPass = await hashPassword(password);
    try {
        const user = await User.create({ username, password: hashedPass , Schoolname, schoolcode });
        if (user) {
            res.status(201).json({
                status: 'success',
                user
            })
        } else {
            res.status(400).json({
                status: 'success',
                user
            })
        }
    } catch (error) {
        res.status(400).json({
            status: 'failed',
            error: error.errors.map((e) => {
                return e.message
            })
        })
    }

}


exports.createSchool = async (req, res) => {
    const { schoolname, schoolcode } = req.body;
    try {
        const school = await school.create({schoolname , schoolcode})
        if (school) {
            res.status(201).json({
                status: 'success',
                school
            })
        } else {
            res.status(400).json({
                status: 'success',
                school
            })
        }
    } catch (error) {
        res.status(400).json({
            status: 'failed',
            error: error.errors.map((e) => {
                return e.message
            })
        })
    }

}



exports.findUserByID = async (req, res) => {
    const { id } = req.body;
    try {
        const user = await User.findByPk(id);
        if (user) {
            res.status(200).json({
                status: 'success',
                user: {
                    name: user.username,
                    email: user.email,
                    school: user.Schoolname,
                    code: user.schoolcode
                }
            })
        } else {
            res.status(404).json({
                status: 'error',
                error: 'User not found'
            })
        }
    } catch (error) {
        res.status(500).json({
            status: 'Error',
            error: 'Somthing Went Wrong'
        })
    }

}