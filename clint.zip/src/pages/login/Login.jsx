import React from "react"
import "./Login.scss"

function Login() {
  return (
    <div>Login</div>
  )
}

export default Login