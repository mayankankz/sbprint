import React from "react"
import "./Register.scss"

function Register() {
  return (
    <div>Register</div>
  )
}

export default Register